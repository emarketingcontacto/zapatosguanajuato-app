@extends('layout')

@section('main-content')
    <div class="container m-4">
        <h1></h1>
        this is bizcategory show
    </div>

@endsection
