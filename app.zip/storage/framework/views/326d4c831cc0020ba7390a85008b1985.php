<?php $__env->startSection('main-content'); ?>

<div  class="container m-4">
    <h1>Create Modelo</h1>

    <form action="<?php echo e(route('Modelo.store')); ?>" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('POST'); ?>

        
        <div class="mb-3">
            <label for="modelId" class="form-label">ID</label>
            <input type="number" name="modelId" class="form-control w-25" disabled>
        </div>

        
        <div class="mb-3">
            <label for="modelName" class="form-label">Model Name</label>
            <input type="text" name="modelName" class="form-control w-25" value="<?php echo e(old('modelName')); ?>" >
            <p class="form-text">Most be 3 characters lenght</p>
            
            <?php $__errorArgs = ['modelName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        
        <div class="mb-3">
            <label for="modelPrice" class="form-label">Model Price</label>
            <input type="text" name="modelPrice" class="form-control w-25" value="<?php echo e(old('modelPrice')); ?>">
            
            <?php $__errorArgs = ['modelPrice'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        
        <div class="mb-3">
            <label for="modelImage" class="form-label">Model Image</label>
            <input type="file" name="modelImage" class="form-control w-25" value="<?php echo e(old('modelImage')); ?>">
            
            <?php $__errorArgs = ['modelImage'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        
        <div class="mb-3">
            <label for="materialId" class="form-control bg-light">Material</label>
            <select name="materialId" class="form-control dropdown w-100">
                <option value="">--Please choose an option--</option>
                <?php $__currentLoopData = $materials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $material): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($material->materialId); ?>"> <?php echo e($material->materialName); ?> </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            
            <?php $__errorArgs = ['materialId'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

         
         <div class="mb-3">
            <label for="seassonId" class="form-control bg-light">Seasson</label>
            <select name="seassonId" class="form-control dropdown w-100">
                <option value="">--Please choose an option--</option>
                <?php $__currentLoopData = $seassons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $seasson): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($seasson->seassonId); ?>"> <?php echo e($seasson->seassonName); ?> </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            
            <?php $__errorArgs = ['seassonId'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>


         
         <div class="mb-3">
            <label for="bizId" class="form-control bg-light">Biz</label>
            <select name="bizId" class="form-control dropdown w-100">
                <option value="">--Please choose an option--</option>
                <?php $__currentLoopData = $business; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $biz): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($biz->bizId); ?>"> <?php echo e($biz->bizName); ?> </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            
            <?php $__errorArgs = ['bizId'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        
        <div class="d-flex flex-row p-3 justify-content-end" >
            <input type="submit" value="Create" class="btn btn-sm btn-primary">
            <a href="/Modelo" class="btn btn-sm btn-danger">Cancel</a>
        </div>


    </form>

</div-container>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ZapatosGuanajuato\zapatosguanajuato-app\resources\views/Modelo/create.blade.php ENDPATH**/ ?>