<?php $__env->startSection('main-content'); ?>

<h1>Edit BizCategory </h1>
<div class="container">
    <form method="POST" action="<?php echo e(route('BizCategory.update', ['bizcategory'=>$Bizcategory])); ?>" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="mb-3">
          <label for="bizcatId" class="form-label">ID</label>
          <input type="number" name="bizcatId" id="bizcatId" class="form-control w-25"
            value="<?php echo e($Bizcategory->bizcatId); ?>" disabled>
        </div>

        <div class="mb-3">
          <label for="bizcatName" class="form-label">Name</label>
          <input type="text"  id="bizcatName"  name="bizcatName"
            value="<?php echo e($Bizcategory->bizcatName); ?>" class="form-control w-50">
        
        <?php $__errorArgs = ['bizcatName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="alert alert-danger"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
         <img src="<?php echo e(asset('storage/'.$Bizcategory->bizcatImage)); ?>" alt="<?php echo e('storage/bizcatimages'); ?>" width="600" height="600">
        </div>

        <div class="mb-3">
            <label for="bizcatImage" class="form-label">Image</label>
            <input type="file"  id="bizcatImage"  name="bizcatImage" class="form-control w-50">
          
          <?php $__errorArgs = ['bizcatName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <div class="alert alert-danger"><?php echo e($message); ?></div>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <button type="submit" class="btn btn-sm btn-primary">Save</button>
        <a href="/BizCategory" class="btn btn-sm btn-danger">Cancel</a>
    </form>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ZapatosGuanajuato\zapatosguanajuato-app\resources\views/BizCategory/edit.blade.php ENDPATH**/ ?>