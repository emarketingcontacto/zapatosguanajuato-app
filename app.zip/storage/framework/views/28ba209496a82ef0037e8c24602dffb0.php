<?php $__env->startSection('main-content'); ?>
<h1>Users</h1>
<div class="container">
        <a href="/User/create" class="btn btn-sm btn-primary">Create</a>
        <hr class="w-50">
        <?php if(session()->has('success')): ?>
            <div id="success" class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
        <table class="table table-striped">
            <thead>
                <tr>
                  <th scope="col">Id</th>
                  <th scope="col">Name</th>
                  <th scope="col">Email</th>
                  <th scope="col">Password</th>
                </tr>
              </thead>
              <tbody>

                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($user['id']); ?></td>
                    <td><?php echo e($user['name']); ?></td>
                    <td><?php echo e($user['email']); ?></td>
                    <td><?php echo e($user['password']); ?></td>
                    <td>
                        <div class="d-flex w-100">
                            
                            <a href="<?php echo e(route('User.edit', ['user'=>$user])); ?>" class="btn btn-sm btn-primary">Edit</a>
                            
                            <form action="<?php echo e(route('User.destroy', ['user'=>$user])); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('delete'); ?>
                                <input type="submit" value="Delete" class="btn btn-sm btn-danger">
                            </form>
                    </div>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ZapatosGuanajuato\zapatosguanajuato-app\resources\views/User/index.blade.php ENDPATH**/ ?>