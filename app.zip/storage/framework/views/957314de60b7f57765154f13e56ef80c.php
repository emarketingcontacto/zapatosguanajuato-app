<?php $__env->startSection('main-content'); ?>

<div class="header-Category" style="background-image: url('<?php echo e(asset('storage/'.$bizcat->bizcatImage)); ?>');">
    <p>Mayoristas</p>
</div>

<div class="container m-4 d-flex gap-3">
    <?php $__currentLoopData = $business; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $biz): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="card" style="width: 18rem;">
        <img src="<?php echo e(asset('storage/'.$biz->bizImage)); ?>" class="card-img-top">
        <h5 class="card-title"><?php echo e($biz->bizName); ?></h5>
        <div class="card-body">
        <p class="card-text"><?php echo e($biz->bizStreetNum); ?></p>
        <p class="card-text"><?php echo e($biz->bizCity); ?>,<?php echo e($biz->bizState); ?></p>
        <p class="card-text"></p>
        <p class="card-text"><?php echo e($biz->bizTel); ?></p>
        
        <a href="<?php echo e(route('Biz.show', ['biz'=>$biz->bizId])); ?>" class="btn btn-sm btn-show form-control">Details</a>
        </div>
    </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ZapatosGuanajuato\zapatosguanajuato-app\resources\views/Wholesalers.blade.php ENDPATH**/ ?>