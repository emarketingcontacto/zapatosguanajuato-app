<?php $__env->startSection('main-content'); ?>

<h1>Edit User</h1>
<div class="container p-5">

    <form action="<?php echo e(route('User.update', ['user'=>$user])); ?>" method="post">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        
        <div class="mb-3">
            <label for="userId" class="form-label">ID</label>
            <input type="number" name="userId" class="form-control w-25" value="<?php echo e($user->id); ?>" disabled>
        </div>

        
        <div class="mb-3">
            <label for="name" class="form-label">Name</label>
            <input type="text" name="name" class="form-control w-25" value="<?php echo e($user->name); ?>" >

            
            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        
        <div class="mb-3">
            <label for="email" class="form-label">Email</label>
            <input type="email" name="email" class="form-control w-25" value="<?php echo e($user->email); ?>" disabled >
            
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

         
         <div class="mb-3">
            <label for="password" class="form-label">Password</label>
            <input type="password" name="password" class="form-control w-25" >
            <p class="form-text">Most be 6 characters lenght</p>
            
            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        
        <div class="mb-3">
            <label for="password_confirmation" class="form-label">Password Confirmation</label>
            <input type="password"  name="password_confirmation" class="form-control w-25">
            <p class="form-text">Most be 6 characters lenght</p>
            
            <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>


        
        <div class="mb-3">
            <label for="created_at" class="form-label">Created </label>
            <input type="datetime" name="created_at" class="form-control w-25" value="<?php echo e($user->created_at); ?>" disabled>
        </div>

        
        <div class="mb-3">
            <label for="updated_at" class="form-label">Last Update </label>
            <input type="datetime" name="updated_at" class="form-control w-25" value="<?php echo e($user->updated_at); ?>" disabled>
        </div>

        

        <div class="mb-3">
            <input type="submit" value="Save" class="btn btn-sm btn-success">
            <a href="/User" class="btn btn-sm btn-danger">Cancel</a>
        </div>

    </form>
</div>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ZapatosGuanajuato\zapatosguanajuato-app\resources\views/User/edit.blade.php ENDPATH**/ ?>