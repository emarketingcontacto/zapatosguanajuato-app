<?php $__env->startSection('main-content'); ?>

<h1>Materials</h1>

<div class="container">
        <a href="/Material/create" class="btn btn-sm btn-primary">Create</a>
        <hr class="w-50">

        <?php if(session()->has('success')): ?>
            <div id="success" class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>


        <table class="table table-striped">

            <thead>
                <tr>
                  <th scope="col">Id</th>
                  <th scope="col">Name</th>
                </tr>
              </thead>
              <tbody>

                <?php $__currentLoopData = $Material; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $material): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($material['materialId']); ?></td>
                    <td><?php echo e($material['materialName']); ?></td>


                    <td>
                        <div class="d-flex w-100">

                        <a href="<?php echo e(route('Material.edit',['material'=>$material])); ?>" class="btn btn-sm btn-primary">Edit</a>
                        <form action="<?php echo e(route('Material.destroy',['material'=>$material])); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('delete'); ?>
                            <input type="submit" value="Delete" class="btn btn-sm btn-danger">
                        </form>

                    </div>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

              </tbody>

        </table>


    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ZapatosGuanajuato\zapatosguanajuato-app\resources\views/Material/index.blade.php ENDPATH**/ ?>