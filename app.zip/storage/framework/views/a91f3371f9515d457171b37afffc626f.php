<div class="hero min-vw-100">
    <div class="hero-text ">
        <h1>Zapatos Guanajuato</h1>
        <h2>Market Place de Calzado</h2>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\ZapatosGuanajuato\zapatosguanajuato-app\resources\views//partials/_hero.blade.php ENDPATH**/ ?>