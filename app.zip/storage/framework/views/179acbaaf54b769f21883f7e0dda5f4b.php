<?php $__env->startSection('main-content'); ?>

<h1>Edit SubCategory</h1>

<div class="container">

    <form action="<?php echo e(route('ModelSubcategory.update',['modelsubcategory'=>$modelsubcategory])); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('put'); ?>

        <div class="mb-2">
            <label for="submodelcatId" class="form-label">ID</label>
            <input type="number" class="form-control w-25" name="modelsubcatId" value="<?php echo e($modelsubcategory->modelsubcatId); ?>" disabled>
        </div>

        <div class="mb-2">
            <label for="modelcatId" class="form-label">Category</label>

            <select name="modelcatId" id="modelcatId" class="form-control dropdown w-25" >

                <option value="">--Please choose an option--</option>

                    <?php $__currentLoopData = $modelcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $modelcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <?php if($modelcategory->modelcatId == $modelsubcategory->modelcatId): ?>
                            <option value="<?php echo e($modelcategory->modelcatId); ?>" selected><?php echo e($modelcategory->modelcatName); ?></option>
                        <?php endif; ?>
                            <option value="<?php echo e($modelcategory->modelcatId); ?>"><?php echo e($modelcategory->modelcatName); ?></option>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="mb-2">
            <label for="modelsubcatName" class="form-label">Name</label>
            <input type="text" name="modelsubcatName" class="form-control w-25" value="<?php echo e($modelsubcategory->modelsubcatName); ?>">
             
            <?php $__errorArgs = ['submodelcatName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        
        <div class="d-flex justify-content-end w-25 ">
            <input type="submit" value="Save" class="btn btn-sm btn-primary mx-2">
            <a href="/ModelSubcategory" class="btn btn-sm btn-danger">Cancel</a>
        </div>
    </form>

</div>
<?php $__env->stopSection(); ?>





<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ZapatosGuanajuato\zapatosguanajuato-app\resources\views/ModelSubcategory/edit.blade.php ENDPATH**/ ?>