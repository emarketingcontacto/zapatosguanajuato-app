<?php $__env->startSection('main-content'); ?>
<h1>Biz</h1>
<div class="container-fluid w-100">
    <a href="/Biz/create" class="btn-btn-sm btn-primary p-2">Create</a>

    <hr class="w-100">

    <table class="w-100 table table-striped">
        <thead>
        <tr>
            <th>Id</th>
            <th>Name</th>
            <th>Street-Number</th>
            <th>Neighborhood</th>
            <th>Sate</th>
            <th>City</th>
            <th>Telephone</th>
            <th>Contact</th>
            <th>WhatsApp</th>
            <th>Facebook</th>
            <th>Website</th>
            <th>Email</th>
            <th>Image</th>
            <th>BizCat</th>
            <th>SaleType</th>
            <th>Management</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $bisness; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $biz): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($biz->bizId); ?></td>
                <td><?php echo e($biz->bizName); ?></td>
                <td><?php echo e($biz->bizStreetNum); ?></td>
                <td><?php echo e($biz->bizNeigborhood); ?></td>
                <td><?php echo e($biz->bizState); ?></td>
                <td><?php echo e($biz->bizCity); ?></td>
                <td><?php echo e($biz->bizTel); ?></td>
                <td><?php echo e($biz->bizContact); ?></td>
                <td><?php echo e($biz->bizWhatsApp); ?></td>
                <td><?php echo e($biz->bizFacebook); ?></td>
                <td><?php echo e($biz->bizWeb); ?></td>
                <td><?php echo e($biz->bizEmail); ?></td>
                <td><?php echo e($biz->bizImage); ?></td>
                <td><?php echo e($biz->bizcatName); ?></td>
                <td><?php echo e($biz->saletypeName); ?></td>
                <td class="d-flex">

                
                <a href="<?php echo e(route('Biz.edit', ['biz'=>$biz->bizId])); ?>" class="btn btn-sm btn-primary">Edit</a>

                
                <form action="<?php echo e(route('Biz.destroy', ['biz'=>$biz->bizId])); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('delete'); ?>
                    <input type="submit" value="Delete" class="btn btn-sm btn-danger mx-2">
                </form>

                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ZapatosGuanajuato\zapatosguanajuato-app\resources\views/Biz/index.blade.php ENDPATH**/ ?>