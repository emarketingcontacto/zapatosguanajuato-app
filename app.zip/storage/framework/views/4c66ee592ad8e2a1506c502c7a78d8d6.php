<?php $__env->startSection('main-content'); ?>

<h1>Edit Seasson</h1>

<div class="container">
    <form method="POST" action="<?php echo e(route('Seasson.update',['seasson' => $Seasson])); ?>")}}">
        <?php echo csrf_field(); ?>
        <?php echo method_field('put'); ?>
        <div class="mb-3">
          <label for="seassonId" class="form-label">ID</label>
          <input type="number" name="seassonId" id="seassonId" class="form-control w-25" disabled value="<?php echo e($Seasson->seassonId); ?>">
        </div>

        <div class="mb-3">
          <label for="seassonName" class="form-label">Name</label>
          <input type="text"  name="seassonName" class="form-control w-50" value="<?php echo e($Seasson->seassonName); ?>"">
        
        <?php $__errorArgs = ['seassonName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="alert alert-danger"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>


        <div class="mb-3">
            <label for="seassonStart" class="form-label">Start Date</label>
            <input type="date"  name="seassonStart" class="form-control w-50" value="<?php echo e($Seasson->seassonStart); ?>"">
          
          <?php $__errorArgs = ['seassonStart'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <div class="alert alert-danger"><?php echo e($message); ?></div>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>

          <div class="mb-3">
            <label for="seassonEnd" class="form-label">Start End</label>
            <input type="date"  name="seassonEnd" class="form-control w-50" value="<?php echo e($Seasson->seassonEnd); ?>"">
          
          <?php $__errorArgs = ['seassonEnd'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <div class="alert alert-danger"><?php echo e($message); ?></div>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>


        <button type="submit" class="btn btn-sm btn-primary">Save</button>
        <a href="/Seasson" class="btn btn-sm btn-danger">Cancel</a>
    </form>
</div>


<?php $__env->stopSection(); ?>



<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ZapatosGuanajuato\zapatosguanajuato-app\resources\views/Seasson/edit.blade.php ENDPATH**/ ?>