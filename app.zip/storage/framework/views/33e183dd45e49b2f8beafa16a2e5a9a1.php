<?php $__env->startSection('main-content'); ?>

<div class="container m-5">
    <h1>Show Model Category </h1>

    <form enctype="multipart/form-data">
        <div class="m-2">
          <label for="modelcatId" class="form-label">ID</label>
          <input type="number" name="modelcatId" id="modelcatId" value="<?php echo e($modelcategory->modelcatId); ?>" class="form-control w-25" disabled>
        </div>

        <div class="mb-2">
          <label for="modelcatName" class="form-label">Name</label>
          <input type="text"  id="modelcatName"  name="modelcatName" value="<?php echo e($modelcategory->modelcatName); ?>" class="form-control w-50">
        </div>

        <div class="mb-2">
            <img src="<?php echo e(asset('storage/'.$modelcategory->modelcatImage)); ?>" alt="<?php echo e('storage/logos'); ?>" width="600" height="600">
        </div>

        
            <a href="<?php echo e(route('ModelCategory.edit',['modelCategory'=>$modelcategory])); ?>" class="btn btn-sm btn-warning">Edit</a>
            <a href="/ModelCategory" class="btn btn-sm btn-danger">Cancel</a>
    </form>

</div> 

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ZapatosGuanajuato\zapatosguanajuato-app\resources\views/ModelCategory/show.blade.php ENDPATH**/ ?>