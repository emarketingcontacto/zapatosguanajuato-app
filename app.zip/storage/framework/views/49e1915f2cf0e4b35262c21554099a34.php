<?php $__env->startSection('main-content'); ?>
<div class="container">
    <div class="row show-banner" style="background-image: url('<?php echo e(asset('storage/'.$biz->bizImage)); ?>')">
        <p class="fw-strong fs-2"><?php echo e($biz->bizName); ?> </p>
    </div>
    <hr class="biz-hr">

    <div class="row m-2">
        <div class="col biz-col-field">Dirección:</div>
        <div class="col biz-col-value"><?php echo e($biz->bizStreetNum); ?></div>
        <div class="col biz-col-field">Colonia:</div>
        <div class="col biz-col-value"><?php echo e($biz->bizNeigborhood); ?></div>
        <div class="col biz-col-field">Estado:</div>
        <div class="col biz-col-value"><?php echo e($biz->bizState); ?></div>
    </div>
    <hr class="biz-hr">

    <div class="row m-2">
        <div class="col biz-col-field">Contacto:</div>
        <div class="col biz-col-value"><?php echo e($biz->bizContact); ?></div>
        <div class="col biz-col-field">Telefono:</div>
        <div class="col biz-col-value">
        <a href="tel:<?php echo e($biz->bizTel); ?>"><?php echo e($biz->bizTel); ?></a>
    </div>
    <hr class="biz-hr">
    <div class="row m-2">
        <div class="col biz-col-field">Email:</div>
        <div class="col biz-col-value">
        <a href="mailto:<?php echo e($biz->bizEmail); ?>"><?php echo e($biz->bizEmail); ?></a></div>
        <div class="col biz-col-field">Website:</div>
        <div class="col biz-col-value">
            <a href="<?php echo e($biz->bizWeb); ?>"><?php echo e($biz->bizWeb); ?></a>
        </div>
    </div>
    <hr class="biz-hr">

    <div class="row m-2">
        <div class="col biz-col-field">WhatsApp:</div>
        <div class="col biz-col-value">
            <a href="https://wa.me/<?php echo e($biz->bizWhatsApp); ?>"><?php echo e($biz->bizWhatsApp); ?></a></div>
        <div class="col biz-col-field">Facebook:</div>
        <div class="col biz-col-value">
            <a href="<?php echo e($biz->bizFacebook); ?>"><?php echo e($biz->bizFacebook); ?></a>
        </div>
    </div>
    <hr class="biz-hr">

    <div class="row m-2">
        <div class="col biz-col-field">Categoria:</div>
        <div class="col biz-col-value"><?php echo e($bizcat->bizcatName); ?></div>
        <div class="col biz-col-field">Tipo de Venta:</div>
        <div class="col biz-col-value"><?php echo e($saletype->saletypeName); ?>: <?php echo e($saletype->saletypeConditions); ?></div>
    </div>
    <hr class="biz-hr">
</div>
<div class="container m-5 d-flex flex-wrap gap-3">
    <?php $__currentLoopData = $modelos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $modelo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card" style="width: 18rem;">
            
            <a href="<?php echo e(route('Modelo.show', ['modelo'=>$modelo->modelId])); ?>">
                <img src="<?php echo e(asset('storage/'.$modelo->modelImage)); ?>" class="card-img-top-modelo" width="300" height="400">
            </a>
            <h5 class="card-title-modelo text-center"><?php echo e($modelo->modelName); ?></h5>
            
            <div class="card-body-modelo">
                <p class="text-sm-center card-text-modelo">Material</p>
                <p class="card-text text-center text-muted"><?php echo e($modelo->materialName); ?></p>
                <p class="text-sm-center card-text-modelo">Precio</p>
                <p class="card-text text-center text-muted">$<?php echo e($modelo->modelPrice); ?>.00</p>
                <p class="text-sm-center card-text-modelo">Temporada</p>
                <p class="card-text text-center text-muted"><?php echo e($modelo->seassonName); ?></p>
                </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ZapatosGuanajuato\zapatosguanajuato-app\resources\views/Biz/show.blade.php ENDPATH**/ ?>