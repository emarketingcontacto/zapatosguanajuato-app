<?php $__env->startSection('main-content'); ?>

<div class="container m-4">

    <h1>Modelos</h1>
    
    <a href="/Modelo/create" class="btn btn-sm btn-primary">Create</a>
    <hr>
    
    <?php if(session()->has('success')): ?>
    <div id="success" class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>

    <?php endif; ?>
    <table class="table-striped w-100" >
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Material</th>
                <th>Price</th>
                <th>Image</th>
                <th>Biz</th>
                <th>Seasson</th>
                <th>Management</th>

            </tr>
        </thead>
        <tbody>
            <tr>
                <?php $__currentLoopData = $modelos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $modelo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <td><?php echo e($modelo->modelId); ?></td>
                <td><?php echo e($modelo->modelName); ?></td>
                <td><?php echo e($modelo->materialName); ?></td>
                <td><?php echo e($modelo->modelPrice); ?></td>
                <td><?php echo e($modelo->modelImage); ?></td>
                <td><?php echo e($modelo->bizName); ?></td>
                <td><?php echo e($modelo->seassonName); ?></td>
                <td class="d-flex">
                    
                        <a href="<?php echo e(route('Modelo.edit',['modelo'=>$modelo->modelId])); ?>" class="btn btn-sm btn-primary">Edit</a>
                    
                    <form action="<?php echo e(route('Modelo.destroy',['modelo'=>$modelo->modelId])); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('delete'); ?>
                        <input type="submit" value="Delete" class="btn btn-sm btn-danger mx-2">
                        </form>
                </td>
            </tr>




            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>


</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ZapatosGuanajuato\zapatosguanajuato-app\resources\views/Modelo/index.blade.php ENDPATH**/ ?>