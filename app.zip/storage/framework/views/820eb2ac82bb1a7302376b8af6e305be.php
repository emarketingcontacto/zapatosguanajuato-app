<?php $__env->startSection('main-content'); ?>

<div class="container">
<h1>Sale Type</h1>

<a href="SaleType/create" class="btn btn-sm btn-primary">Create</a>

<hr class="w-100">

<?php if(session()->has('success')): ?>
<div id="success" class="alert alert-success">
    <?php echo e(session('success')); ?>

</div>
<?php endif; ?>

    <table class="table table-striped w-100">
        <thead>
            <tr>
                <th>Id</th>
                <th>Name</th>
                <th>Conditions</th>
                <th>Manager</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $saletypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $saletype): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($saletype ['saletypeId']); ?></td>
                    <td><?php echo e($saletype ['saletypeName']); ?></td>
                    <td><?php echo e($saletype['saletypeConditions']); ?></td>
                    <td class="management">
                        <div class="d-flex">

                            
                            <a href="<?php echo e(route('SaleType.edit', ['saletype' => $saletype])); ?>" class="btn btn-sm btn-primary">Edit</a>

                            
                        <form action="<?php echo e(route('SaleType.destroy', ['saletype' => $saletype])); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('delete'); ?>
                            <input type="submit" value="Delete" class="btn btn-sm btn-danger mx-2">
                        </form>
                    </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ZapatosGuanajuato\zapatosguanajuato-app\resources\views/SaleType/index.blade.php ENDPATH**/ ?>