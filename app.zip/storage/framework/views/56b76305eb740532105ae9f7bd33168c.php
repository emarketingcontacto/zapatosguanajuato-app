<?php $__env->startSection('main-content'); ?>

<h1>ModelCategories</h1>

<div class="container">
    <a href="/ModelCategory/create" class="btn btn-sm btn-primary">Create</a>
    <hr class="w-50">

    <?php if(session()->has('success')): ?>
        <div id="success" class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <table class="table table-striped w-50">
        <thead>
            <tr>
                <td>Id</td>
                <td>Name</td>
                <td>Image</td>
                <td>Manager</td>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $ModelCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $modelcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($modelcategory['moodelcatId']); ?></td>
                <td><?php echo e($modelcategory['modelcatName']); ?></td>
                <td><?php echo e($modelcategory['modelcatImage']); ?></td>

                <td>
                    <div class="d-flex">
                    <a href="<?php echo e(route('ModelCategory.show',['modelCategory'=>$modelcategory])); ?>" class="btn btn-sm btn-primary mx-1">Show</a>

                    <a href="<?php echo e(route('ModelCategory.edit',['modelCategory'=>$modelcategory])); ?>" class="btn btn-sm btn-primary mx-1">Edit</a>

                    <form action="<?php echo e(route('ModelCategory.destroy', ['modelCategory'=>$modelcategory])); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('delete'); ?>
                    <input type="submit" value="Delete" class="btn btn-sm btn-danger mx-2">
                    </form>
                </div>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>


</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ZapatosGuanajuato\zapatosguanajuato-app\resources\views/ModelCategory/index.blade.php ENDPATH**/ ?>