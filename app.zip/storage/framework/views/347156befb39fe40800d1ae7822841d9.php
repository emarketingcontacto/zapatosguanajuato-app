<?php $__env->startSection('main-content'); ?>

<h1>Biz Categories</h1>
<div class="container">
    <a href="/BizCategory/create" class="btn btn-sm btn-primary">Create</a>
    <hr class="w-50">

    <?php if(session()->has('success')): ?>
    <div id="success" class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>

    <?php endif; ?>

    <table class="table table-striped w-50">
        <thead>
            <tr>
                <th>Id</th>
                <th>Name</th>
                <th>Image</th>
                <th>Manager</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $Bizcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bizcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($bizcategory['bizcatId']); ?></td>
                <td><?php echo e($bizcategory['bizcatName']); ?></td>
                <td><?php echo e($bizcategory['bizcatImage']); ?></td>

                <td>
                    <div class="d-flex">
                    <a href="<?php echo e(route('BizCategory.edit',['bizcategory'=>$bizcategory->bizcatId])); ?>" class="btn btn-sm btn-primary">Edit</a>
                    <form action="<?php echo e(route('BizCategory.destroy',['bizcategory'=>$bizcategory])); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('delete'); ?>
                    <input type="submit" value="Delete" class="btn btn-sm btn-danger mx-2">
                    </form>
                </div>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>


</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ZapatosGuanajuato\zapatosguanajuato-app\resources\views/BizCategory/index.blade.php ENDPATH**/ ?>