<?php $__env->startSection('main-content'); ?>

<h1>Edit Sale Types</h1>

    <div class="container">
        <form method="post" action="<?php echo e(route('SaleType.update', ['saletype'=>$saletype])); ?>">
            <?php echo method_field('PUT'); ?>
            <?php echo csrf_field(); ?>
            <div class="mb-2 row">
                <label for="saletypeId" class="form-control">ID</label>
                <input type="number" name="saletypeId"  class="form-control" value="<?php echo e($saletype->saletypeId); ?>" disabled>
            </div>

            <div class="mb-2 row">
                <label for="saletypeName" class="form-control">Name</label>
                <input type="text" name="saletypeName" class="form-control" value="<?php echo e($saletype->saletypeName); ?>">
                
                <?php $__errorArgs = ['saletypeName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="mb-2 row">
                <label for="saletypeConditions" class="form-control">Conditions</label>
                <textarea type="textarea" name="saletypeConditions" class="form-control" rows="5" cols="20">
                    <?php echo e($saletype->saletypeConditions); ?>

                </textarea>
                
                <?php $__errorArgs = ['saletypeConditions'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="mb-2 d-flex justify-content-end">
                <input type="submit" value="Save" class="btn btn-sm btn-primary">
                <a href="/SaleType" class="btn btn-sm btn-danger">Cancel</a>
            </div>



        </form>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ZapatosGuanajuato\zapatosguanajuato-app\resources\views/SaleType/edit.blade.php ENDPATH**/ ?>