<?php $__env->startSection('main-content'); ?>

<h1>This is Biz Categories</h1>

<table class="table table-striped">
    <thead>
        <tr>
            <td>Id</td>
            <td>Name</td>
            <td>Manager</td>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $bizcategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($data['bizcatId']); ?></td>
            <td><?php echo e($data['bizcatName']); ?></td>
            <td>
                <input type="submit" value="Edit" class="btn btn-sm btn-primary">
                <input type="submit" value="Delete" class="btn btn-sm btn-danger">
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ZapatosGuanajuato\zapatosguanajuato-app\resources\views/management/bizcategories.blade.php ENDPATH**/ ?>