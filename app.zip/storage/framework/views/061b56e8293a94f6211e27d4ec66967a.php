<?php $__env->startSection('main-content'); ?>

<div class="container mb-5 text-center">
    <div class="row d-flex flex-column justify-center align-content-center">
            <img src="<?php echo e(asset('storage/'.$modelo->modelImage)); ?>" height="100%" width="100%">
            <p class="fw-strong fs-2 hero-text m-n15"><?php echo e($modelo->modelName); ?></p>
    </div>

        <div class="row">
            <div class="col text-end">Distribuido por:</div>
            <div class="col text-start biz-col-value">
                <a href="<?php echo e(route('Biz.show', ['biz'=>$biz->bizId])); ?>">
                    <?php echo e($biz->bizName); ?>

                </a>
            </div>
        </div>

        <div class="row">
            <div class="col text-end text-secondary">Precio</div>
            <div class="col text-start biz-col-value"><?php echo e($modelo->modelPrice); ?></div>
        </div>

        <div class="row">
            <div class="col text-end text-secondary">Material</div>
            <div class="col text-start biz-col-value"><?php echo e($material->materialName); ?></div>
        </div>

        <div class="row">
            <div class="col text-end text-secondary">Temporada</div>
            <div class="col text-start biz-col-value"><?php echo e($seasson->seassonName); ?></div>
        </div>

        <div class="row">
            <div class="col text-end text-secondary">Disponible desde:</div>
            <div class="col text-start biz-col-value"><?php echo e($seasson->seassonStart); ?></div>

        </div>

        <div class="row">
            <div class="col text-end text-secondary">Hasta</div>
            <div class="col text-start biz-col-value"><?php echo e($seasson->seassonEnd); ?> </div>
        </div>




    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ZapatosGuanajuato\zapatosguanajuato-app\resources\views/Modelo/show.blade.php ENDPATH**/ ?>